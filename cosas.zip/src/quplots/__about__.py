# SPDX-FileCopyrightText: 2025-present Adrian <kerpador@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
