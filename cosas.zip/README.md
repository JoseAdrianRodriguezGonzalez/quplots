# QuPlots

[![PyPI - Version](https://img.shields.io/pypi/v/quplots.svg)](https://pypi.org/project/quplots)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/quplots.svg)](https://pypi.org/project/quplots)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install quplots
```

## License

`quplots` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
